<?php

session_start();

include("../dir-php/function.php");

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Latinbets - A melhor casa de apostas da america latina</title>
  
  <link rel="shortcut icon" href="img/latinbets-icone.png" type="image/x-icon">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <link rel="stylesheet" href="css/style.css">

</head>


<body>
  <header>
    <div class="area-logo">
      <a href="#">
        <img src="img/logo.png" alt="Latinbets" width="200px">
      </a>
    </div>

    <div class="title-perfil">
      <div class="left">
        <span>Dashborad do usuário</span>
      </div>

      <div class="right">
        <a href="../" class="btn-fechar">
          <div>
            <img src="img/icones/x.png" alt="Fechar" width="20px">
          </div>
          <span class="esc">ESC</span>
        </a>
      </div>
    </div>

    <nav id="nav">
      <button aria-label="Abrir Menu" id="btn-mobile" aria-haspopup="true" aria-controls="menu" aria-expanded="false">Menu
        <span id="hamburger"></span>
      </button>
      <ul id="menu" role="menu">
        <li>
          <a href="carteira.php" class="">
            <img src="img/icones/carteira.png" alt="Sua Carteira" width="20px">
            Carteira
          </a>
        </li>

        <li>
          <a href="bonus.php" class="">
            <img src="img/icones/bonus.png" alt="Seus Bônus" width="20px">
            Bônus
          </a>
        </li>

        <li>
          <a href="apostas.php" class="">
            <img src="img/icones/apostas.png" alt="Suas Apostas" width="20px">
            Apostas
          </a>
        </li>

        <li>
          <a href="index.php" class="">
            <img src="img/icones/perfil.png" alt="Dados da sua Conta" width="20px">
            Conta
          </a>
        </li>

        <li>
          <a href="notificacoes.php" class="">
            <img src="img/icones/notificacao.png" alt="Suas Notificações" width="20px">
            Notificações
          </a>
        </li>

        <li>
          <a href="suporte.php" class="">
            <img src="img/icones/suporte.png" alt="Suporte" width="20px">
            Suporte
          </a>
        </li>

        <li>
          <a href="afiliados.php" class="">
            <img src="img/icones/afiliado.png" alt="Torne-se Afiliado" width="20px">
            The Revolution
          </a>
        </li>

        <li>
          <a href="../logout.php" class="btn-sair">
            Sair
          </a>
        </li>
      </ul>
    </nav>
  </header>
  <main>
    <div class="menu-perfil">
      <ul class="mb-5">
        <li>
          <a href="carteira.php" class="">
            <img src="img/icones/carteira.png" alt="Sua Carteira" width="20px">
            Carteira
          </a>
        </li>

        <li>
          <a href="bonus.php" class="">
            <img src="img/icones/bonus.png" alt="Seus Bônus" width="20px">
            Bônus
          </a>
        </li>

        <li>
          <a href="apostas.php" class="">
            <img src="img/icones/apostas.png" alt="Suas Apostas" width="20px">
            Apostas
          </a>
        </li>

        <li>
          <a href="index.php" class="">
            <img src="img/icones/perfil.png" alt="Dados da sua Conta" width="20px">
            Conta
          </a>
        </li>

        <li>
          <a href="notificacoes.php" class="">
            <img src="img/icones/notificacao.png" alt="Suas Notificações" width="20px">
            Notificações
          </a>
        </li>

        <li>
          <a href="suporte.php" class="">
            <img src="img/icones/suporte.png" alt="Suporte" width="20px">
            Suporte
          </a>
        </li>

        <li>
          <a href="afiliados.php" class="">
            <img src="img/icones/afiliado.png" alt="Torne-se Afiliado" width="20px">
            The Revolution
          </a>
        </li>

        
      </ul>
      <div>
        <a href="../logout.php" class="btn-sair">
          Sair
        </a>
      </div>
    </div>
    