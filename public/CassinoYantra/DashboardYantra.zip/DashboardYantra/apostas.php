  <?php include("sections/header.php"); ?>

<link rel="stylesheet" href="/v2/dashboard/css/style.css">
<style type="text/css">


.encerraraposta-bilhete {
    color: #FFF;
    background-color: #ce9513;
    font-weight: 600;
    font-size: 12px;
    padding: 10px 50px !important;
    border: 2px solid #FFF;
    border-radius: 5px;
}
.main-meusbilhetes {
  
  width: 80vw;
  min-height: 400px;
}

.main-meusbilhetes .header-meusbilhetes {
  margin-top: 1%;
  background-color: rgba(0, 0, 0, 0.3);
  border-radius: 10px;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 5px;
  position: relative;
  padding: 0px;
}

.main-meusbilhetes .header-meusbilhetes .left {
  background-color: rgba(0, 0, 0, 0.3);
  width: 100%;
  display: flex;
  align-items: center;
  padding: 0.75rem;
  border-radius: 10px;
}

.main-meusbilhetes .header-meusbilhetes ul {
  display: flex;
}

.main-meusbilhetes .header-meusbilhetes ul li {
  margin-right: 10px !important;
  font-size: 12px;
  font-weight: 500;
  padding-bottom: 10px !important;
}

.main-meusbilhetes .header-meusbilhetes ul li a {
  white-space: nowrap;

  top: 6px;
  color: #FFF;
  display: block;
  padding: 9px 5px !important;
}

.header-meusbilhetes ul .item.selected {
  border-bottom: 3px solid #f7b207;
}

.title-meusbilhetes {
   display: flex;
   flex-direction: column;
  font-size: 14px;
  color: #FFF;
  border-radius: 5px;
  padding: 7px 5px !important;
  top: 10px;
}

.title-tiposbilhetes {

  font-size: 15px;
  font-weight: 600;
  color: #FFF;
  padding: 10px 0px !important;
  margin-left: 13px !important;

}
.bilhetes-aovoivo .collapse .title-tiposbilhetes{

  display: flex;
   flex-direction: column;
}

.conteudo-bilhetes {
  margin: 10px;
  border-radius: 5px;
  color: #FFF;
  font-size: 12px;
  background-color: #36373c;
}

.valoretipo-apostabilhete {
  font-weight: 600;
  font-size: 15px;
  padding: 10px;
  border-bottom: 1px solid #323b45;
  cursor: pointer;
  display: flex;
  align-items: center;
}

.subtitle-valoretipo {
  font-size: 11px;
  font-weight: normal;
  margin-left: 1%;
  display: flex;
  align-items: center;
}

.subtitle-valoretipo span {
    margin: 0 !important;
    position: absolute;
    right: 20px;
    border-radius: 5px;
    font-weight: 600;
    color: #FFF !important;
    padding: 2px 5px;
    min-width: 80px;
    text-align: center;
}

.titulo-aposta {
  padding: 10px;
}

.titulo-aposta div {
  font-size: 14px;
  font-weight: 600;
}

.titulo-aposta.odd {
  margin-left: 15%;
}

.condicoes-aposta {
  padding: 10px;
  border-bottom: 1px solid #323b45;
}

.item-condicoes {
  margin-bottom: 2%;
}

.subtitle-condicoes {
  font-size: 11px;
}

.resultado-bilhete {
  display: flex;
  align-items: center;
  padding: 10px;
}

.resultado-bilhete div {
  width: 50%;
}

.valor-footerbilhete {
  font-size: 15px;
  font-weight: 600;
}

.encerraraposta-bilhete-cima {
  color: #FFF;
  background-color: #ce9513;
  font-weight: 600;
  font-size: 12px;
  padding: 6px 10px !important;
  border: 2px solid #FFF;
  border-radius: 5px;
  display: block;
}

.encerraraposta-bilhete {
  color: #FFF;
  background-color: #f12c4c;
  font-weight: 600;
  font-size: 12px;
  padding: 10px 50px !important;
  border: 2px solid #FFF;
  border-radius: 5px;
}

.valor-encerraraposta {
  font-size: 14px;
}

</style>


<main class="main-meusbilhetes">
    <div class="header-meusbilhetes container-fluid">
        <div class="left">
          <ul>
            <li class="item selected">
              <span class="title-meusbilhetes">Apostas:</span>
            </li>
            
            <li class="item">
              <a href="#multiCollapsePendentes" data-bs-toggle="collapse">Pendentes</a>
            </li>
            <li class="item">
              <a href="#multiCollapseResolvidos" data-bs-toggle="collapse">Resolvidos</a>
            </li>
            <li class="item">
              <a href="#" data-bs-toggle="collapse" data-bs-target=".multi-collapse">Todos</a>
            </li>
            <li class="item">
              <a href="#" data-bs-toggle="collapse" data-bs-target="">Cassino</a>
            </li>
          </ul>
        </div>
    

    <div class="bilhetes-aovoivo">
      <div class="collapse multi-collapse" id="multiCollapseAovivo">
        <p class="title-tiposbilhetes">Ao vivo</p>
                <?php

          $query2 = "SELECT * FROM `apostas` WHERE usuario = '{$_SESSION["usuario"]}' and tt = '0'";
          $result2 = mysqli_query($conn, $query2);

          $idd = 0;

          while ($row = mysqli_fetch_array($result2)){

              $idd += 1;

              $a = trim($row["aposta"],'["');
              $b = trim($a,'"]');
              $c = trim($b,'","');

              if ($row["result"] == 0) {$result = "";}
              if ($row["result"] == 1) {$result = "Ganhou";}
              if ($row["result"] == 2) {$result = "Perdeu";}
              if ($row["result"] == 3) {$result = "Estornada";}


              if (count(json_decode($row["aposta"])) > 1) {
                // code...
                $titles = "Multipla, ".count(json_decode($row["aposta"]))." Jogos";
              }else{  
                 $titles = explode('-', json_decode($row["aposta"])[0])[0];
              }
              $seguir = true;
              foreach (json_decode($row["aposta"]) as &$valor) {
                  
                  
                  $time = explode('-', $valor)[2];
                  
                  
                  
                  if((intval(explode(':', $time)[0]) - intval($hora_autal) <= 0 && intval(explode(':', $time)[0]) - intval($hora_autal)  >= -1) or strcmp($time, " ao/vivo") == 4) { if($seguir == true){ $seguir = false;
                      
                      
                      
                      
                      
                      

          ?>

            <div class="conteudo-bilhetes">
              <div class="valoretipo-apostabilhete" data-bs-toggle="collapse" data-bs-target="#collapseAovivo<?=$idd;?>">
                <span><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"], 2, ',', '.');?></span>
                <span class="subtitle-valoretipo"><?=$titles;?><?=$result?></span>
              </div>

              <div class="collapse" id="collapseAovivo<?=$idd;?>">

                <?php  
                
                    $count_individual = -1;
                  foreach (json_decode($row["aposta"]) as &$valor) {
                      
                    $count_individual++;
                    $result_individual = "";
                    if(explode(',', $row["individual"])[$count_individual] == 1){$result_individual = "✅";}  
                    if(explode(',', $row["individual"])[$count_individual] == 2){$result_individual = "❌";}  
                    

                ?>

                <div class="titulo-aposta">
                  <div>
                    <span><?=$result_individual?><?=explode('-', $valor)[1];?></span>
                   
                  </div>
                  <span><?=explode('-', $valor)[0];?></span><br>
                  <span><?= $row["data"] ?></span>


                </div>

                <?php } ?>
                
                <div class="resultado-bilhete">
                  <div>
                    <span>Aposta</span>
                    <br>
                    <span class="valor-footerbilhete"><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"], 2, ',', '.');?></span>
                  </div>
                  <div>
                      
                      <?php
                      
                        $maxin = vdata($_SESSION["usuario"])["moeda"] == "BRL" ? 10000 : 5000 ;
                        
                        if(($row["entrada"] * $row["odd"]) >= $maxin ){
                                                        
                            $retornos = 10000;
                            
                        }else{
                            
                            $retornos = $row["entrada"] * $row["odd"];
                        }
                      
                      
                      
                      ?>
                      
                      
                    <span>Ganhos potenciais</span>
                    <br>
                    <span class="valor-footerbilhete"><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($retornos, 2, ',', '.');?></span>
                  </div>
                  <!--
                  <div>
                    <a href="#" class="encerraraposta-bilhete">
                      Encerrar Aposta
                      <span class="valor-encerraraposta"><?= vdata($_SESSION["usuario"])["moeda"]?> 0,00</span>
                    </a>
                  </div>
                -->
                </div>
              </div>
            </div>


        <?php }}}} ?>
      </div>
    </div>
    
    
    <div class="bilhetes-aovoivo">
      <div class="collapse multi-collapse" id="multiCollapseResolvidos">
        <p class="title-tiposbilhetes">Resolvidos</p>
        <?php

          $query2 = "SELECT * FROM `apostas` WHERE usuario = '{$_SESSION["usuario"]}' and result != '0'";
          $result2 = mysqli_query($conn, $query2);

          $idd = 0;

          while ($row = mysqli_fetch_array($result2)){

              $idd += 1;

              $a = trim($row["aposta"],'["');
              $b = trim($a,'"]');
              $c = trim($b,'","');

              if ($row["result"] == 0) {$result = "";}
              if ($row["result"] == 1) {
                  $result = "Ganhou";
                  $cor_result = "#7cb342";
                  
              }
              if ($row["result"] == 2) {
                  $result = "Perdeu";
                  $cor_result = "#f44336";
                  
              }
              
              if ($row["result"] == 3) {
                  $result = "Estornada";
                   $cor_result = "#9e9e9e";
                  
              }


              if (count(json_decode($row["aposta"])) > 1) {
                // code...
                $titles = "Multipla, ".count(json_decode($row["aposta"]))." Jogos";
              }else{
                 $titles = explode('-', json_decode($row["aposta"])[0])[0];
              }

          ?>

            <div class="conteudo-bilhetes">
              <div class="valoretipo-apostabilhete" data-bs-toggle="collapse" data-bs-target="#collapseAovivo<?=$idd;?>">
                <span><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"], 2, ',', '.');?></span>
                <span class="subtitle-valoretipo"><?=$titles;?><span style="border-width: medium;
  border-style: solid;
  border-color: #9ccc6500;margin: 42px;background-color: <?=$cor_result?>;color: black;font-size: 13px;"><?=$result?></span></span>
              </div>

              <div class="collapse" id="collapseAovivo<?=$idd;?>">

                <?php  
                
                    $count_individual = -1;
                  foreach (json_decode($row["aposta"]) as &$valor) {
                      
                    $count_individual++;
                    $result_individual = "";
                    if(explode(',', $row["individual"])[$count_individual] == 1){$result_individual = "✅";}  
                    if(explode(',', $row["individual"])[$count_individual] == 2){$result_individual = "❌";}  
                    

                ?>

                <div class="titulo-aposta">
                  <div>
                    <span><?=$result_individual?><?=explode('-', $valor)[1];?></span>
                   
                  </div>
                  <span><?=explode('-', $valor)[0];?></span><br>
                  <span><?= $row["data"] ?></span>


                </div>

                <?php } ?>
                
                <div class="resultado-bilhete">
                  <div>
                    <span>Aposta</span>
                    <br>
                    <span class="valor-footerbilhete"><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"], 2, ',', '.');?></span>
                  </div>
                  <div>
                    <span>Ganhos potenciais</span>
                    <br>
                    <span class="valor-footerbilhete"><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"] * $row["odd"], 2, ',', '.');?></span>
                  </div>
                  <!--
                  <div>
                    <a href="#" class="encerraraposta-bilhete">
                      Encerrar Aposta
                      <span class="valor-encerraraposta"><?= vdata($_SESSION["usuario"])["moeda"]?> 0,00</span>
                    </a>
                  </div>
                -->
                </div>
              </div>
            </div>


        <?php } ?>
      </div>
    </div>
    
   

    <div class="bilhetes-aovoivo">
      <div class="multi-collapse collapse show" id="multiCollapsePendentes">
        <p class="title-tiposbilhetes">Pendentes</p>
        <?php

          $query2 = "SELECT * FROM `apostas` WHERE 'usuario' = '{$_SESSION["usuario"]}' and result = '0'";
          $result2 = mysqli_query($conn, $query2);

          $idd = 0;

          while ($row = mysqli_fetch_array($result2)){

              $idd += 1;

              $a = trim($row["aposta"],'["');
              $b = trim($a,'"]');
              $c = trim($b,'","');

              if ($row["result"] == 0) {$result = "";}
              if ($row["result"] == 1) {$result = "Ganhou";}
              if ($row["result"] == 2) {$result = "Perdeu";}
              if ($row["result"] == 3) {$result = "Estornada";}


              if (count(json_decode($row["aposta"])) > 1) {
                // code...
                $titles = "Multipla, ".count(json_decode($row["aposta"]))." Jogos";
              }else{
                 $titles = json_decode($row["aposta"])[0];
              }

          ?>

            <div class="conteudo-bilhetes">
              <div class="valoretipo-apostabilhete" data-bs-toggle="collapse" data-bs-target="#collapseAovivo<?=$idd;?>">
                <span><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"], 2, ',', '.');?></span>
                <span class="subtitle-valoretipo"><?=$titles;?><span><?=$result?></span></span>
              </div>

              <div class="collapse" id="collapseAovivo<?=$idd;?>">

                <?php  
                
                    $count_individual = -1;
                  foreach (json_decode($row["aposta"]) as &$valor) {
                      
                    $count_individual++;
                    $result_individual = "";
                    if(explode(',', $row["individual"])[$count_individual] == 1){$result_individual = "✅";}  
                    if(explode(',', $row["individual"])[$count_individual] == 2){$result_individual = "❌";}  
                    

                ?>

                <div class="titulo-aposta">
                  <div>
                    <span><?=$result_individual?><?=explode('-', $valor)[1];?></span>
                   
                  </div>
                  <span><?=explode('-', $valor)[0];?></span><br>
                  <span><?= $row["data"] ?></span>


                </div>

                <?php } ?>
                
                <div class="resultado-bilhete">
                  <div>
                    <span>Aposta</span>
                    <br>
                    <span class="valor-footerbilhete"><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"], 2, ',', '.');?></span>
                  </div>
                  <div>
                    <span>Ganhos potenciais</span>
                    <br>
                    <span class="valor-footerbilhete"><?= vdata($_SESSION["usuario"])["moeda"]?> <?=number_format($row["entrada"] * $row["odd"], 2, ',', '.');?></span>
                  </div>
                  <!--
                  <div>
                    <a href="#" class="encerraraposta-bilhete">
                      Encerrar Aposta
                      <span class="valor-encerraraposta"><?= vdata($_SESSION["usuario"])["moeda"]?> 0,00</span>
                    </a>
                  </div>
                -->
                </div>
              </div>
            </div>


        <?php } ?>
      </div>
    </div>
        </div>
  
        
  
  </main>

  <?php include("sections/footer.php"); ?>