 <?php include("sections/header.php"); ?>

  <main>
    
    <div class="conteudo-perfil">
      <section class="box-bonus">
        <div class="card-bonus mb-4">
            <div class="left">
              <img src="https://cdn-icons-png.flaticon.com/512/1156/1156949.png" alt="" width="100%">
            </div>

            <div class="right">
                <h2>Latinbets 2.0</h2>
            
                <h4>Velocidade, eu sou a velocidade. ⚡⚡⚡</h4>


                
                <form class="mb-2">
                    <label style="position: relative;left: 0px;">
                        
                       <strong style="color: #bf8513;"><a co="" href="http://seulinkaqui.com" target="popup" onclick="window.open('TERMOS E CONDIÇÕES.pdf','popup','width=600,height=600'); return false;" style="color: #bf8513;">Veja tudo sobre nossa nova atualização </a>.
                    </label>
                </form>
            
              
            </div>
        </div>
      </section>
    </div>
  </main>



 <?php include("sections/footer.php"); ?>