 <?php include("sections/header.php"); ?>
    
    <main>
    
    <div class="conteudo-perfil">
      <section class="box-bonus">
        <div class="card-bonus mb-4">
            <div class="left">
              <img src="https://cdn-icons-png.flaticon.com/512/1156/1156949.png" alt="" width="100%">
            </div>

            <div class="right">
                <h2>Em Breve!</h2>
                <p>Estamos preparando tudo para você</p>
            </div>
        </div>
      </section>
    </div>
  </main>


 <?php include("sections/footer.php"); ?>